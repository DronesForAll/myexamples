<html>
<head>
<title>d4asec container test 1</title>
<style>
body{
	background-color:#434343;
	color:#cdcdcd;
}
</style>
</head>
<body>
<center><h2>drones4All d4asec container test1</h2></center>
<br><br><br><br>
<center><h2>Test1: checking if php works with containers ;)</h2></center>
<br><br><br><br>
<center><h2>YOUR FLAG IS: php<?php echo phpversion(); ?>ContainerOK
</body>
</html>
